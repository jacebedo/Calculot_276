package cmpt276.g14.mathappg14;

import android.os.Bundle;

public class MedievalGameActivity extends MainActivity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_medieval_game);
	}
	
}
