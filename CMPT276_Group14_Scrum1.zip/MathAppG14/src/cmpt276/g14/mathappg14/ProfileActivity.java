package cmpt276.g14.mathappg14;

import android.app.Activity;
import android.os.Bundle;


public class ProfileActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_profile);
	}


}
