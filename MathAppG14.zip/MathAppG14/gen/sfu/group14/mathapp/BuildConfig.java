/** Automatically generated file. DO NOT MODIFY */
package sfu.group14.mathapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}