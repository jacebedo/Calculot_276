package sfu.group14.mathapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sign_up_or_login);
	}
	
	public void onClick_SignUp(View view){
		Intent goToSignUp = new Intent(MainActivity.this,SignUp.class);
		startActivity(goToSignUp);
	}
	
	public void onClick_Login(View view){
		Intent goToLogin = new Intent(MainActivity.this,Login.class);
		startActivity(goToLogin);
	}
	
}
