package sfu.group14.mathapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class SignUp extends MainActivity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sign_up);
	}
	
	public void onClick_sign_up_sign_up(View view){
		Toast.makeText(getApplicationContext(), "You are now registered!", Toast.LENGTH_LONG).show();
		finish();
	}
}
