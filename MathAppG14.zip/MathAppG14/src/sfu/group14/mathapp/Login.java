package sfu.group14.mathapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Login extends MainActivity{
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
	}
	
	public void onClick_login_login(View view){
		Intent goToLoginEnterPassword = new Intent(Login.this,LoginEnterPassword.class);
		startActivity(goToLoginEnterPassword);
	}
}
