package sfu.group14.mathapp;

import android.os.Bundle;

public class Topics extends MainActivity{
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.topics);
	}
	
}
