package cmpt276.g14.mathappg14.Topics;

import android.app.Activity;
import android.os.Bundle;
import cmpt276.g14.mathappg14.R;


public class Topic11 extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_topic11);
	}


}
