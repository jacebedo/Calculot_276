/** Automatically generated file. DO NOT MODIFY */
package cmpt276.g14.mathappg14;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}